﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Робот
{
    internal class Robot1
    {
        public int kollife;
        public int getlife()
        {
            return kollife;
        }

        public void min (int a)
        {
            Random rnd = new Random();
            kollife = a;
            kollife = rnd.Next(0, (a * 70 / 100));
        }
        public void kol(int a, int k)
        {
            if (k == a / 2)
            {
                kollife = kollife + 30;
            }
            else
                if (k == a * 0.7)
            {
                kollife += 20;
            }
            else
                 if (k >= a / 2 && k < a * 0.7)
            {
                kollife += 40;
            }
            else 
                if(k<a/2 && k>0)
            {
                kollife += 50;
            }
            else
                if(k==0)
            {
                kollife += 100;
            }
        }
    }
}
